package net.mcreator.bloodworld;

public class MCreatorRecipeBloodDrop2 extends bloodworld.ModElement {

	public MCreatorRecipeBloodDrop2(bloodworld instance) {
		super(instance);
	}
}
