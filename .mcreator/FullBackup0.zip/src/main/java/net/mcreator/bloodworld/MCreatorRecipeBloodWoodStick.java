package net.mcreator.bloodworld;

public class MCreatorRecipeBloodWoodStick extends bloodworld.ModElement {

	public MCreatorRecipeBloodWoodStick(bloodworld instance) {
		super(instance);
	}
}
