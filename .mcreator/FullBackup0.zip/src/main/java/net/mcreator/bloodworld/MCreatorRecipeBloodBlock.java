package net.mcreator.bloodworld;

public class MCreatorRecipeBloodBlock extends bloodworld.ModElement {

	public MCreatorRecipeBloodBlock(bloodworld instance) {
		super(instance);
	}
}
