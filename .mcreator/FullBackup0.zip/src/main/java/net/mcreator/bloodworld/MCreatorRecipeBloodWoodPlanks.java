package net.mcreator.bloodworld;

public class MCreatorRecipeBloodWoodPlanks extends bloodworld.ModElement {

	public MCreatorRecipeBloodWoodPlanks(bloodworld instance) {
		super(instance);
	}
}
