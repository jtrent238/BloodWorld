package net.mcreator.bloodworld;

public class MCreatorRecipeBloodDrop3 extends bloodworld.ModElement {

	public MCreatorRecipeBloodDrop3(bloodworld instance) {
		super(instance);
	}
}
