package net.mcreator.bloodworld;

public class MCreatorRecipeBloodstoneBrick extends bloodworld.ModElement {

	public MCreatorRecipeBloodstoneBrick(bloodworld instance) {
		super(instance);
	}
}
