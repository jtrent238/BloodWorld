package net.mcreator.bloodworld;

public class MCreatorRecipeBloodDrop extends bloodworld.ModElement {

	public MCreatorRecipeBloodDrop(bloodworld instance) {
		super(instance);
	}
}
