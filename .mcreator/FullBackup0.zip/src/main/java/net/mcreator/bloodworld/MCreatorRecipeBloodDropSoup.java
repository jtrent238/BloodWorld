package net.mcreator.bloodworld;

public class MCreatorRecipeBloodDropSoup extends bloodworld.ModElement {

	public MCreatorRecipeBloodDropSoup(bloodworld instance) {
		super(instance);
	}
}
